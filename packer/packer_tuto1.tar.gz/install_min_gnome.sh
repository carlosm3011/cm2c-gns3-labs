#!/bin/sh

# # 2.
# apt-get install -y xserver-xorg xserver-xorg-core xfonts-base xinit \
#  --no-install-recommends

# # 3.
# apt-get install -y libgl1-mesa-dri x11-xserver-utils gnome-session \
#   gnome-shell gnome-themes gnome-terminal gnome-control-center nautilus \
#   gnome-icon-theme --no-install-recommends

# # 4.
# apt-get install -y gdm3 --no-install-recommends

# apt-get -y install vanilla-gnome-desktop --no-install-recommends

# tasksel install ubuntu-mate-core
# apt-get -y install ubuntu-mate-core --no-install-recommends
apt-get -y install ubuntu-mate-core