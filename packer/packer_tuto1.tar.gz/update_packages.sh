#!/bin/sh

apt -y update
apt -y dist-upgrade

# sudo apt install -y 
